  let x;
  let y;
  let w;
  let z;
  let count;
  let n;
let size;

function setup() {
  createCanvas(400, 400);
  background(220);
  
  size= 10;
  count=0;
  
  n =97356100078777;
  col(n);

}

  x=10;
  y=10;
  w= 390;
  z= 390;

function col(n){
  if( n%2 == 0 && n!=1){
    n=n/2;
    fill(255,0,0);
    ellipse(y,x,10,10);
   movef();
    print(n);
      if(n!=1){
        col(n);
      } 
  } else{
    n=(3*n)+1;
    fill(0,0,255);
    ellipse(w,z,10,10);
    moveb();
    print(n);
      if(n!=1){
        col(n);
      }
  }
  count++;
  print(count);
 }

function movef(){
x= x+10;
    if (x>= height){
      y=y+10;
      x=10;      
    }
}

function moveb(){
z= z-10;
    if (z<= 0){
      w=w-10;
      z=390;      
    }
}
